// generated from rosidl_generator_c/resource/idl.h.em
// with input from tutorial_interfaces:msg/ComputerInfo.idl
// generated code does not contain a copyright notice

#ifndef TUTORIAL_INTERFACES__MSG__COMPUTER_INFO_H_
#define TUTORIAL_INTERFACES__MSG__COMPUTER_INFO_H_

#include "tutorial_interfaces/msg/detail/computer_info__struct.h"
#include "tutorial_interfaces/msg/detail/computer_info__functions.h"
#include "tutorial_interfaces/msg/detail/computer_info__type_support.h"

#endif  // TUTORIAL_INTERFACES__MSG__COMPUTER_INFO_H_
